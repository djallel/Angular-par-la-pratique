Application pour randonneur permettant de pratiquer Angular 2
