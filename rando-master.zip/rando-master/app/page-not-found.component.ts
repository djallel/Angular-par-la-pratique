import { Component } from '@angular/core';

@Component({
    template: `
        <div>Oups, page non trouvée</div>
    `
})
export class PageNotFoundComponent {}